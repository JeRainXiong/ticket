
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
</head>
<body>
    <img src="data:image/png;base64,<?php echo $png_base64; ?>" alt="票">
</body>
</html>