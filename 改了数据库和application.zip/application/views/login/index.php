<?php include VIEW_PATH . "/common/head.php" ?>
</head>
<body>

<div class="login-component" style="display: block;">
    <div class="pop"></div>
    <div class="pop_login">
        <ul class="pop_login_title"><img src="img/logo.png" class="main-logo"></ul>
        <dl>
            <dt>欢迎登录学霸蟹</dt>
        </dl>
        <ul class="pop_login_form">
            <li id="li_cellphone"><input placeholder="手机号" id="js_login_phone"></li>
          
            <li id="li_myzm"><input placeholder="密码" id="js_top_yzm"></li>
            <li id="li_login"><a id="js_login_btn" href="javascript:void(0);">登录</a></li>
        </ul>
    </div>

</div>
</body>
</html>