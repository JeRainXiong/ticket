<?php include VIEW_PATH . "/common/head.php" ?>

</head>

  <body>
<?php include VIEW_PATH . "/common/nav.php" ?>    

    <!-- 频道区一 -->
    <div class="navbar-channel" id="channel">
        <div class="container">
            <ul>
                <li class="active"><a href="/">首页<div class="border-bottom"></div></a></li>
              <!--   <li><a href="/list?type=1">演唱会<div class="border-bottom"></div></a></li>
              <li><a href="/list?type=3">话剧歌剧<div class="border-bottom"></div></a></li>               
              <li><a href="/list?type=6">体育赛事<div class="border-bottom"></div></a></li>
              <li><a href="/list?type=2">音乐会<div class="border-bottom"></div></a></li>
              <li><a href="/list?type=9">儿童亲子<div class="border-bottom"></div></a></li>
              <li><a href="/list?type=5">舞蹈芭蕾<div class="border-bottom"></div></a></li>
              <li><a href="/list?type=7">展览休闲<div class="border-bottom"></div></a></li>
              <li><a href="/list?type=4">曲艺杂谈<div class="border-bottom"></div></a></li> -->
                <li style="display: inline-block;padding-left:100%;"></li>
            </ul>
        </div>
    </div>
    <div class="homepage-body" >
        <div class="slide-component-section" style="display:none">
            <div class="slider-container-wrapper">
            <div class="slider-container">
                <a class="left-slide">
                    <i class="icon icon-banner-left"></i>
                </a>
                <a class="right-slide">
                    <i class="icon icon-banner-right"></i>
                </a>
            </div>
            </div>
            <div class="slide-component-container" style="visibility: visible;">

            <div class="slide-component" style="left: -3670.67px;">
                <div class="mask"></div>
                <a href="/content/59f2ed81a251d86dd72011bf" data-sabannername="【上海站】“光影秘境”国际新媒体艺术特展 INFINITE DIMENSIONS IN DIGITAL ART AND BEYOND" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="59e84e480cf229749e5cbb21" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/5phDT3HWQF.jpg">
                </a>
            </div>   
            
            <div class="slide-component" style="left: -3054.33px;">
                <div class="mask"></div>
                <a href="http://www.tking.club/2018newyear/index.html?channel=h5pcsh10" data-sabannername="" data-sabannertypedisplayname="活动" data-sabannertypecode="4" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a7d84bae4b05b83cb03450f" target="_blank">
                    <img src="https://img2.tking.cn/assets/img/TKNHWnYQMa.jpg">
                </a>
            </div><div class="slide-component" style="left: -2438px;">
                <div class="mask"></div>
                <a href="https://activity.tking.cn/topicTemplate/index.html?templateID=5a7fd451c756b101b0075b7b" data-sabannername="" data-sabannertypedisplayname="活动" data-sabannertypecode="4" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a84096ce4b0a146cdf93b5f" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/WGtyQm6386.jpg">
                </a>
            </div><div class="slide-component" style="left: -1821.67px;">
                <div class="mask"></div>
                <a href="/content/599cde790cf205cf15aa46a1" data-sabannername="【上海站】法语原版经典音乐剧《罗密欧与朱丽叶》" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="59e84e100cf229749e5cba80" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/MYzi7eEaxM.jpg">
                </a>
            </div><div class="slide-component" style="left: -1205.33px;">
                <div class="mask"></div>
                <a href="/content/5a669503908c3860aa21492b" data-sabannername="【上海站】放浪新世代 2018“狂热飓风”" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a20ec690cf2a47beabecde1" target="_blank">
                    <img src="https://img0.tking.cn/assets/img/QPDj7chzHM.jpg">
                </a>
            </div><div class="slide-component" style="left: -589px;">
                <div class="mask"></div>
                <a href="/content/5a72b550908c380b7e06747b" data-sabannername="【上海站】Bruno Mars 布鲁诺·马尔斯 24K魔法世界巡演" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a3c7124e4b0f810996cd6b6" target="_blank">
                    <img src="https://img0.tking.cn/assets/img/rScd5AXp7y.jpg">
                </a>
            </div><div class="slide-component" style="left: 27.3333px;">
                <div class="mask"></div>
                <a href="/content/5a74164bc756b101b039b99a" data-sabannername="【上海站】张艺谋《对话•寓言2047》" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="59fc283c0cf2e69cf51e6559" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/6JWtCaxMs2.jpg">
                </a>
            </div><div class="slide-component active" style="left: 180.5px;">
                <div class="mask"></div>
                <a href="/content/59f2ed81a251d86dd72011bf" data-sabannername="【上海站】“光影秘境”国际新媒体艺术特展 INFINITE DIMENSIONS IN DIGITAL ART AND BEYOND" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="59e84e480cf229749e5cbb21" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/5phDT3HWQF.jpg">
                </a>
            </div><div class="slide-component" style="left: 643.667px;">
                <div class="mask"></div>
                <a href="http://www.tking.club/2018newyear/index.html?channel=h5pcsh10" data-sabannername="" data-sabannertypedisplayname="活动" data-sabannertypecode="4" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a7d84bae4b05b83cb03450f" target="_blank">
                    <img src="https://img2.tking.cn/assets/img/TKNHWnYQMa.jpg">
                </a>
            </div><div class="slide-component" style="left: 1260px;">
                <div class="mask"></div>
                <a href="https://activity.tking.cn/topicTemplate/index.html?templateID=5a7fd451c756b101b0075b7b" data-sabannername="" data-sabannertypedisplayname="活动" data-sabannertypecode="4" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a84096ce4b0a146cdf93b5f" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/WGtyQm6386.jpg">
                </a>
            </div><div class="slide-component" style="left: 1876.33px;">
                <div class="mask"></div>
                <a href="/content/599cde790cf205cf15aa46a1" data-sabannername="【上海站】法语原版经典音乐剧《罗密欧与朱丽叶》" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="59e84e100cf229749e5cba80" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/MYzi7eEaxM.jpg">
                </a>
            </div><div class="slide-component" style="left: 2492.67px;">
                <div class="mask"></div>
                <a href="/content/5a669503908c3860aa21492b" data-sabannername="【上海站】放浪新世代 2018“狂热飓风”" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a20ec690cf2a47beabecde1" target="_blank">
                    <img src="https://img0.tking.cn/assets/img/QPDj7chzHM.jpg">
                </a>
            </div><div class="slide-component" style="left: 3109px;">
                <div class="mask"></div>
                <a href="/content/5a72b550908c380b7e06747b" data-sabannername="【上海站】Bruno Mars 布鲁诺·马尔斯 24K魔法世界巡演" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="5a3c7124e4b0f810996cd6b6" target="_blank">
                    <img src="https://img0.tking.cn/assets/img/rScd5AXp7y.jpg">
                </a>
            </div><div class="slide-component" style="left: 3725.33px;">
                <div class="mask"></div>
                <a href="/content/5a74164bc756b101b039b99a" data-sabannername="【上海站】张艺谋《对话•寓言2047》" data-sabannertypedisplayname="演出" data-sabannertypecode="3" data-sabannercategorycode="1" data-sabannercategorydisplayname="首页轮播图" data-sashowtypedisplayname="全部类型" data-sabanneroid="59fc283c0cf2e69cf51e6559" target="_blank">
                    <img src="https://img1.tking.cn/assets/img/6JWtCaxMs2.jpg">
                </a>
            </div></div>
        </div>
        <div class="page-section-row">
            <div id="hot-section" class="page-section left-part">
                <div class="page-section-header">
                    <div class="section-name">近期热门</div>
                    <div class="section-operation">
                        <a href="/list?sorting=weight&amp;seq=desc" target="_blank">查看更多<span class="right-arrow"></span></a>
                    </div>
                </div>
                <div class="section-shows">
                    
                        
                        <a target="_blank" href="/content/c?concert=1" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】John Legend 2018年中国巡回演唱会" data-sashowoid="5a4c96fc908c385cd14ddba5" data-sashowtype="1" data-showtypedisplayname="演唱会">
                            <div class="image-holder">
                                <img src="https://img0.tking.cn/assets/img/s4hTERzJEX.jpg" data-src="https://img0.tking.cn/assets/img/s4hTERzJEX.jpg" alt="【上海站】John Legend 2018年中国巡回演唱会">
                            </div>
                            <div title="【上海站】John Legend 2018年中国巡回演唱会" class="show-detail">
                                【上海站】John Legend 2018年中国巡回演唱会
                            </div>
                            <div class="show-price">
                                344
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                        
                        <a target="_blank" href="/content/5a7d3da4c756b101b0878c87" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】2018咪咕音乐现场SNH48《红玫瑰与白玫瑰》" data-sashowoid="5a7d3da4c756b101b0878c87" data-sashowtype="1" data-showtypedisplayname="演唱会">
                            <div class="image-holder">
                                <img src="https://img2.tking.cn/assets/img/YDTXMch4Ca.jpg" data-src="https://img2.tking.cn/assets/img/YDTXMch4Ca.jpg" alt="【上海站】2018咪咕音乐现场SNH48《红玫瑰与白玫瑰》">
                            </div>
                            <div title="【上海站】2018咪咕音乐现场SNH48《红玫瑰与白玫瑰》" class="show-detail">
                                【上海站】2018咪咕音乐现场SNH48《红玫瑰与白玫瑰》
                            </div>
                            <div class="show-price">
                                118
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                        
                        <a target="_blank" href="/content/5a5d5ef2c756b172b082041f" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】开心麻花爆笑舞台剧《乌龙山伯爵》" data-sashowoid="5a5d5ef2c756b172b082041f" data-sashowtype="3" data-showtypedisplayname="话剧歌剧">
                            <div class="image-holder">
                                <img src="https://img1.tking.cn/assets/img/zTH65xJ2Wx.jpg" data-src="https://img1.tking.cn/assets/img/zTH65xJ2Wx.jpg" alt="【上海站】开心麻花爆笑舞台剧《乌龙山伯爵》">
                            </div>
                            <div title="【上海站】开心麻花爆笑舞台剧《乌龙山伯爵》" class="show-detail">
                                【上海站】开心麻花爆笑舞台剧《乌龙山伯爵》
                            </div>
                            <div class="show-price">
                                133
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                        
                        <a target="_blank" href="/content/5a74164bc756b101b039b99a" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】张艺谋《对话•寓言2047》" data-sashowoid="5a74164bc756b101b039b99a" data-sashowtype="3" data-showtypedisplayname="话剧歌剧">
                            <div class="image-holder">
                                <img src="https://img2.tking.cn/assets/img/5wG6GMDKWP.jpg" data-src="https://img2.tking.cn/assets/img/5wG6GMDKWP.jpg" alt="【上海站】张艺谋《对话•寓言2047》">
                            </div>
                            <div title="【上海站】张艺谋《对话•寓言2047》" class="show-detail">
                                【上海站】张艺谋《对话•寓言2047》
                            </div>
                            <div class="show-price">
                                368
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                        
                        <a target="_blank" href="/content/59fadb416204e62c7ef882f7" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】四幕爆笑舞台剧《牡丹亭不停》 " data-sashowoid="59fadb416204e62c7ef882f7" data-sashowtype="3" data-showtypedisplayname="话剧歌剧">
                            <div class="image-holder">
                                <img src="https://img1.tking.cn/assets/img/zjYpQEBm3h.jpg" data-src="https://img1.tking.cn/assets/img/zjYpQEBm3h.jpg" alt="【上海站】四幕爆笑舞台剧《牡丹亭不停》 ">
                            </div>
                            <div title="【上海站】四幕爆笑舞台剧《牡丹亭不停》 " class="show-detail">
                                【上海站】四幕爆笑舞台剧《牡丹亭不停》 
                            </div>
                            <div class="show-price">
                                70
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                        
                        <a target="_blank" href="/content/5993a4a70cf2d54d47adff5e" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】孟京辉导演话剧《恋爱的犀牛》 " data-sashowoid="5993a4a70cf2d54d47adff5e" data-sashowtype="3" data-showtypedisplayname="话剧歌剧">
                            <div class="image-holder">
                                <img src="https://img2.tking.cn/assets/img/pS6Bmsxtec.jpg" data-src="https://img2.tking.cn/assets/img/pS6Bmsxtec.jpg" alt="【上海站】孟京辉导演话剧《恋爱的犀牛》 ">
                            </div>
                            <div title="【上海站】孟京辉导演话剧《恋爱的犀牛》 " class="show-detail">
                                【上海站】孟京辉导演话剧《恋爱的犀牛》 
                            </div>
                            <div class="show-price">
                                102
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                        
                        <a target="_blank" href="/content/5a3c6676908c383ce413b0a2" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】欢乐祥和团圆年——元宵节音乐会" data-sashowoid="5a3c6676908c383ce413b0a2" data-sashowtype="2" data-showtypedisplayname="音乐会">
                            <div class="image-holder">
                                <img src="https://img1.tking.cn/assets/img/8kZwGKTJKa.jpg" data-src="https://img1.tking.cn/assets/img/8kZwGKTJKa.jpg" alt="【上海站】欢乐祥和团圆年——元宵节音乐会">
                            </div>
                            <div title="【上海站】欢乐祥和团圆年——元宵节音乐会" class="show-detail">
                                【上海站】欢乐祥和团圆年——元宵节音乐会
                            </div>
                            <div class="show-price">
                                302
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                        
                        <a target="_blank" href="/content/5a7a63a5c756b101b0d6d4db" class="section-show sa_recent" data-sasectionname="首页近期" data-sashowname="【上海站】古典名画音乐会《画布上的音符》" data-sashowoid="5a7a63a5c756b101b0d6d4db" data-sashowtype="2" data-showtypedisplayname="音乐会">
                            <div class="image-holder">
                                <img src="https://img2.tking.cn/assets/img/aXD5HJmcAN.jpg" data-src="https://img2.tking.cn/assets/img/aXD5HJmcAN.jpg" alt="【上海站】古典名画音乐会《画布上的音符》">
                            </div>
                            <div title="【上海站】古典名画音乐会《画布上的音符》" class="show-detail">
                                【上海站】古典名画音乐会《画布上的音符》
                            </div>
                            <div class="show-price">
                                101
                                <span class="price-unit">元起</span>
                            </div>
                        </a>
                        
                    
                    
                        
                    
                        
                    
                        
                    
                        
                    
                        
                    
                        
                    
                        
                    
                        
                    
                    
                </div>
            </div>
            <div class="page-section right-part">
                <div class="page-section-header">
                    <div class="section-name">人气TOP 5</div>
                    <div class="section-operation">
                        <a href="/list?sorting=weight&amp;seq=desc" target="_blank">查看更多<span class="right-arrow"></span></a>
                    </div>
                </div>
                <div class="section-shows">
                    
                    <a target="_blank" href="/content/55da971f0cf2789befd52a49" class="sa_hot_click best-show-item first" data-sasectionname="首页人气" data-sashowname="【上海站】上海杂技团《欢乐马戏》" data-sashowoid="55da971f0cf2789befd52a49" data-sashowtype="4" data-showtypedisplayname="曲艺杂谈">
                        <div class="show-index">1</div>
                        <div class="image-holder">
                            <img src="https://img1.tking.cn/assets/img/1440388888662.欢乐马戏.jpg" data-src="https://img1.tking.cn/assets/img/1440388888662.欢乐马戏.jpg" alt="【上海站】上海杂技团《欢乐马戏》">
                        </div>
                        <div class="show-detail">
                            <div title="【上海站】上海杂技团《欢乐马戏》" class="show-name">
                                【上海站】上海杂技团《欢乐马戏》
                            </div>
                            <div class="show-info">
                                2018.03.10 10:00
                            </div>
                            <div class="show-info">
                                上海马戏城-中剧场
                            </div>
                        </div>
                    </a>
                    
                    <a target="_blank" href="/content/574d5df30cf254685b32673e" class="sa_hot_click best-show-item " data-sasectionname="首页人气" data-sashowname="【上海站】上海迪士尼乐园门票" data-sashowoid="574d5df30cf254685b32673e" data-sashowtype="7" data-showtypedisplayname="展览休闲">
                        <div class="show-index">2</div>
                        <div class="image-holder">
                            <img src="https://img0.tking.cn/assets/img/tzwjy3CRKN.jpg" data-src="https://img0.tking.cn/assets/img/tzwjy3CRKN.jpg" alt="【上海站】上海迪士尼乐园门票">
                        </div>
                        <div class="show-detail">
                            <div title="【上海站】上海迪士尼乐园门票" class="show-name">
                                【上海站】上海迪士尼乐园门票
                            </div>
                            <div class="show-info">
                                2018.02.28 09:00
                            </div>
                            <div class="show-info">
                                上海迪士尼度假区
                            </div>
                        </div>
                    </a>
                    
                    <a target="_blank" href="/content/5a348750908c381edea60618" class="sa_hot_click best-show-item " data-sasectionname="首页人气" data-sashowname="【上海站】2018费玉清演唱会" data-sashowoid="5a348750908c381edea60618" data-sashowtype="1" data-showtypedisplayname="演唱会">
                        <div class="show-index">3</div>
                        <div class="image-holder">
                            <img src="https://img2.tking.cn/assets/img/iR5CjCDFxB.jpg" data-src="https://img2.tking.cn/assets/img/iR5CjCDFxB.jpg" alt="【上海站】2018费玉清演唱会">
                        </div>
                        <div class="show-detail">
                            <div title="【上海站】2018费玉清演唱会" class="show-name">
                                【上海站】2018费玉清演唱会
                            </div>
                            <div class="show-info">
                                2018.03.31 19:30
                            </div>
                            <div class="show-info">
                                上海梅赛德斯奔驰文化中心（上海世博文化中心）
                            </div>
                        </div>
                    </a>
                    
                    <a target="_blank" href="/content/5a351d5ac756b14e37db0a2a" class="sa_hot_click best-show-item " data-sasectionname="首页人气" data-sashowname="【上海站】2018冰雪王国之爱丽丝梦游仙境" data-sashowoid="5a351d5ac756b14e37db0a2a" data-sashowtype="7" data-showtypedisplayname="展览休闲">
                        <div class="show-index">4</div>
                        <div class="image-holder">
                            <img src="https://img0.tking.cn/assets/img/Y4fcN5PG43.jpg" data-src="https://img0.tking.cn/assets/img/Y4fcN5PG43.jpg" alt="【上海站】2018冰雪王国之爱丽丝梦游仙境">
                        </div>
                        <div class="show-detail">
                            <div title="【上海站】2018冰雪王国之爱丽丝梦游仙境" class="show-name">
                                【上海站】2018冰雪王国之爱丽丝梦游仙境
                            </div>
                            <div class="show-info">
                                2018.03.08 10:00
                            </div>
                            <div class="show-info">
                                上海世博庆典广场
                            </div>
                        </div>
                    </a>
                    
                    <a target="_blank" href="/content/5a1d1078a251d83c4d1b9845" class="sa_hot_click best-show-item " data-sasectionname="首页人气" data-sashowname="【上海站】世界经典原版音乐剧《猫》CATS" data-sashowoid="5a1d1078a251d83c4d1b9845" data-sashowtype="3" data-showtypedisplayname="话剧歌剧">
                        <div class="show-index">5</div>
                        <div class="image-holder">
                            <img src="https://img2.tking.cn/assets/img/4Yj5BRWpnY.jpg" data-src="https://img2.tking.cn/assets/img/4Yj5BRWpnY.jpg" alt="【上海站】世界经典原版音乐剧《猫》CATS">
                        </div>
                        <div class="show-detail">
                            <div title="【上海站】世界经典原版音乐剧《猫》CATS" class="show-name">
                                【上海站】世界经典原版音乐剧《猫》CATS
                            </div>
                            <div class="show-info">
                                2018.06.07 19:30
                            </div>
                            <div class="show-info">
                                上汽·上海文化广场
                            </div>
                        </div>
                    </a>
                    
                </div>
            </div>
        </div>
        
                </div>
            </div>
            </div>
        </div>

    </div>
   
<?php include VIEW_PATH . "/common/login.php" ?>

<script type="text/javascript" src="js/common/page.js"></script>
</body>
</html>